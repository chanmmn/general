-- Create the mediadata database
CREATE DATABASE mediadata;

-- Connect to mediadata database
\c mediadata;

-- Create the capture_devices table
CREATE TABLE capture_devices (
    id SERIAL PRIMARY KEY,
    name VARCHAR(150) NOT NULL
);

-- Create the media_collections table
CREATE TABLE media_collections (
    id SERIAL PRIMARY KEY,
    upload_date DATE NOT NULL,
    status VARCHAR(100) NOT NULL,
    is_deleted BOOLEAN DEFAULT FALSE,
    media_id VARCHAR(100) NOT NULL,
    file_size_mb DECIMAL(10, 2) NOT NULL,
    device_id INT NOT NULL,
    FOREIGN KEY (device_id) REFERENCES capture_devices(id)
);

-- Insert sample data into capture_devices
INSERT INTO capture_devices (name) VALUES
('Camera Device 1'),
('Camera Device 2'),
('Camera Device 3'),
('Audio Recorder A'),
('Video Capture B'),
('Mobile Phone Camera'),
('Security Camera'),
('Surveillance Unit 1'),
('Studio Camera Pro'),
('Drone Camera');

-- Insert sample data into media_collections (100 records)
-- Using dates from 2023-08-01 to 2024-07-31 to match the query in the paper
INSERT INTO media_collections (upload_date, status, is_deleted, media_id, file_size_mb, device_id) VALUES
('2023-08-05', 'ACTIVE', false, 'MED_001', 250.50, 1),
('2023-08-10', 'ACTIVE', false, 'MED_002', 320.75, 2),
('2023-08-15', 'ACTIVE', false, 'MED_003', 180.25, 3),
('2023-08-20', 'ACTIVE', false, 'MED_004', 450.00, 4),
('2023-08-25', 'INACTIVE', false, 'MED_005', 200.00, 5),
('2023-09-01', 'ACTIVE', false, 'MED_006', 275.50, 1),
('2023-09-05', 'ACTIVE', false, 'MED_007', 300.25, 2),
('2023-09-10', 'ACTIVE', false, 'MED_008', 125.75, 3),
('2023-09-15', 'ACTIVE', false, 'MED_009', 500.00, 4),
('2023-09-20', 'ACTIVE', false, 'MED_010', 220.00, 5),
('2023-10-01', 'ACTIVE', false, 'MED_011', 310.50, 1),
('2023-10-05', 'ACTIVE', false, 'MED_012', 280.75, 2),
('2023-10-10', 'ACTIVE', false, 'MED_013', 150.25, 3),
('2023-10-15', 'ACTIVE', false, 'MED_014', 420.00, 4),
('2023-10-20', 'ACTIVE', false, 'MED_015', 210.00, 5),
('2023-11-01', 'ACTIVE', false, 'MED_016', 290.50, 1),
('2023-11-05', 'ACTIVE', false, 'MED_017', 310.75, 2),
('2023-11-10', 'ACTIVE', false, 'MED_018', 165.25, 3),
('2023-11-15', 'ACTIVE', false, 'MED_019', 480.00, 4),
('2023-11-20', 'ACTIVE', false, 'MED_020', 230.00, 5),
('2023-12-01', 'ACTIVE', false, 'MED_021', 270.50, 1),
('2023-12-05', 'ACTIVE', false, 'MED_022', 330.75, 2),
('2023-12-10', 'ACTIVE', false, 'MED_023', 140.25, 3),
('2023-12-15', 'ACTIVE', false, 'MED_024', 510.00, 4),
('2023-12-20', 'ACTIVE', false, 'MED_025', 240.00, 5),
('2024-01-01', 'ACTIVE', false, 'MED_026', 260.50, 1),
('2024-01-05', 'ACTIVE', false, 'MED_027', 320.75, 2),
('2024-01-10', 'ACTIVE', false, 'MED_028', 175.25, 3),
('2024-01-15', 'ACTIVE', false, 'MED_029', 430.00, 4),
('2024-01-20', 'ACTIVE', false, 'MED_030', 250.00, 5),
('2024-02-01', 'ACTIVE', false, 'MED_031', 280.50, 1),
('2024-02-05', 'ACTIVE', false, 'MED_032', 310.75, 2),
('2024-02-10', 'ACTIVE', false, 'MED_033', 155.25, 3),
('2024-02-15', 'ACTIVE', false, 'MED_034', 490.00, 4),
('2024-02-20', 'ACTIVE', false, 'MED_035', 220.00, 5),
('2024-03-01', 'ACTIVE', false, 'MED_036', 300.50, 1),
('2024-03-05', 'ACTIVE', false, 'MED_037', 330.75, 2),
('2024-03-10', 'ACTIVE', false, 'MED_038', 160.25, 3),
('2024-03-15', 'ACTIVE', false, 'MED_039', 450.00, 4),
('2024-03-20', 'ACTIVE', false, 'MED_040', 260.00, 5),
('2024-04-01', 'ACTIVE', false, 'MED_041', 270.50, 1),
('2024-04-05', 'ACTIVE', false, 'MED_042', 320.75, 2),
('2024-04-10', 'ACTIVE', false, 'MED_043', 180.25, 3),
('2024-04-15', 'ACTIVE', false, 'MED_044', 520.00, 4),
('2024-04-20', 'ACTIVE', false, 'MED_045', 230.00, 5),
('2024-05-01', 'ACTIVE', false, 'MED_046', 290.50, 1),
('2024-05-05', 'ACTIVE', false, 'MED_047', 310.75, 2),
('2024-05-10', 'ACTIVE', false, 'MED_048', 150.25, 3),
('2024-05-15', 'ACTIVE', false, 'MED_049', 470.00, 4),
('2024-05-20', 'ACTIVE', false, 'MED_050', 240.00, 5),
('2024-06-01', 'ACTIVE', false, 'MED_051', 310.50, 1),
('2024-06-05', 'ACTIVE', false, 'MED_052', 340.75, 2),
('2024-06-10', 'ACTIVE', false, 'MED_053', 170.25, 3),
('2024-06-15', 'ACTIVE', false, 'MED_054', 440.00, 4),
('2024-06-20', 'ACTIVE', false, 'MED_055', 250.00, 5),
('2024-07-01', 'ACTIVE', false, 'MED_056', 280.50, 1),
('2024-07-05', 'ACTIVE', false, 'MED_057', 320.75, 2),
('2024-07-10', 'ACTIVE', false, 'MED_058', 160.25, 3),
('2024-07-15', 'ACTIVE', false, 'MED_059', 500.00, 4),
('2024-07-20', 'ACTIVE', false, 'MED_060', 220.00, 5);

-- Insert more sample data to reach approximately 200 records for comprehensive testing
INSERT INTO media_collections (upload_date, status, is_deleted, media_id, file_size_mb, device_id) VALUES
('2023-08-06', 'ACTIVE', false, 'MED_061', 235.50, 6),
('2023-08-11', 'ACTIVE', false, 'MED_062', 310.75, 7),
('2023-08-16', 'ACTIVE', false, 'MED_063', 195.25, 8),
('2023-08-21', 'ACTIVE', false, 'MED_064', 460.00, 9),
('2023-08-26', 'INACTIVE', false, 'MED_065', 210.00, 10),
('2023-09-02', 'ACTIVE', false, 'MED_066', 265.50, 6),
('2023-09-06', 'ACTIVE', false, 'MED_067', 310.25, 7),
('2023-09-11', 'ACTIVE', false, 'MED_068', 135.75, 8),
('2023-09-16', 'ACTIVE', false, 'MED_069', 510.00, 9),
('2023-09-21', 'ACTIVE', false, 'MED_070', 230.00, 10),
('2023-10-02', 'ACTIVE', false, 'MED_071', 320.50, 6),
('2023-10-06', 'ACTIVE', false, 'MED_072', 290.75, 7),
('2023-10-11', 'ACTIVE', false, 'MED_073', 160.25, 8),
('2023-10-16', 'ACTIVE', false, 'MED_074', 430.00, 9),
('2023-10-21', 'ACTIVE', false, 'MED_075', 220.00, 10),
('2023-11-02', 'ACTIVE', false, 'MED_076', 300.50, 6),
('2023-11-06', 'ACTIVE', false, 'MED_077', 320.75, 7),
('2023-11-11', 'ACTIVE', false, 'MED_078', 175.25, 8),
('2023-11-16', 'ACTIVE', false, 'MED_079', 490.00, 9),
('2023-11-21', 'ACTIVE', false, 'MED_080', 240.00, 10),
('2023-12-02', 'ACTIVE', false, 'MED_081', 280.50, 6),
('2023-12-06', 'ACTIVE', false, 'MED_082', 340.75, 7),
('2023-12-11', 'ACTIVE', false, 'MED_083', 150.25, 8),
('2023-12-16', 'ACTIVE', false, 'MED_084', 520.00, 9),
('2023-12-21', 'ACTIVE', false, 'MED_085', 250.00, 10),
('2024-01-02', 'ACTIVE', false, 'MED_086', 270.50, 6),
('2024-01-06', 'ACTIVE', false, 'MED_087', 330.75, 7),
('2024-01-11', 'ACTIVE', false, 'MED_088', 185.25, 8),
('2024-01-16', 'ACTIVE', false, 'MED_089', 440.00, 9),
('2024-01-21', 'ACTIVE', false, 'MED_090', 260.00, 10),
('2024-02-02', 'ACTIVE', false, 'MED_091', 290.50, 6),
('2024-02-06', 'ACTIVE', false, 'MED_092', 320.75, 7),
('2024-02-11', 'ACTIVE', false, 'MED_093', 165.25, 8),
('2024-02-16', 'ACTIVE', false, 'MED_094', 500.00, 9),
('2024-02-21', 'ACTIVE', false, 'MED_095', 230.00, 10),
('2024-03-02', 'ACTIVE', false, 'MED_096', 310.50, 6),
('2024-03-06', 'ACTIVE', false, 'MED_097', 340.75, 7),
('2024-03-11', 'ACTIVE', false, 'MED_098', 170.25, 8),
('2024-03-16', 'ACTIVE', false, 'MED_099', 460.00, 9),
('2024-03-21', 'ACTIVE', false, 'MED_100', 270.00, 10);

-- Add generated columns to support date-based grouping without function calls
ALTER TABLE media_collections ADD COLUMN IF NOT EXISTS upload_year INT GENERATED ALWAYS AS (EXTRACT(YEAR FROM upload_date)) STORED;
ALTER TABLE media_collections ADD COLUMN IF NOT EXISTS upload_month INT GENERATED ALWAYS AS (EXTRACT(MONTH FROM upload_date)) STORED;

-- Create the AI-recommended indexes based on the paper's findings

-- Index 1: Join optimization index on device_id (foreign key)
CREATE INDEX idx_media_device_id ON media_collections(device_id);

-- Index 2: Composite index for filtering (status, is_deleted, upload_date)
-- This supports the WHERE clause filters efficiently
CREATE INDEX idx_media_filters ON media_collections(status, is_deleted, upload_date);

-- Index 3: Covering index that includes file_size_mb for aggregate queries
-- This enables index-only scans for the GROUP BY and SUM() operations
CREATE INDEX idx_media_covering ON media_collections(device_id, upload_date, file_size_mb)
INCLUDE (status, is_deleted);

-- Index 4: Index on generated columns for date-based grouping
-- This replaces the MONTH() and YEAR() function calls
CREATE INDEX idx_media_year_month ON media_collections(upload_year, upload_month, device_id);

-- Index 5: Index on media_id for NOT LIKE filtering optimization
-- While NOT LIKE patterns can't use indexes directly, having an index helps with general queries
CREATE INDEX idx_media_id ON media_collections(media_id);

-- Display the table structures
\d capture_devices;
\d media_collections;

-- Show all indexes
\di;

-- Display sample data verification
SELECT '=== Sample Data from capture_devices ===' as info;
SELECT * FROM capture_devices LIMIT 10;

SELECT '=== Sample Data Count ===' as info;
SELECT COUNT(*) as total_records FROM media_collections;

SELECT '=== Media Collections by Device ===' as info;
SELECT 
    cd.name,
    COUNT(mc.id) as record_count,
    SUM(mc.file_size_mb) as total_size_mb
FROM media_collections mc
JOIN capture_devices cd ON mc.device_id = cd.id
GROUP BY cd.name
ORDER BY total_size_mb DESC;
