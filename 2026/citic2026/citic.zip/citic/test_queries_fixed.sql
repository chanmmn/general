-- Test Query from the Paper: Demonstrating AI-Recommended Index Benefits
-- This is the exact query mentioned in the paper that benefits from the AI-recommended indexes

SELECT   
    EXTRACT(MONTH FROM media_collections.upload_date) AS "Month",
    EXTRACT(YEAR FROM media_collections.upload_date) AS "Year",
    SUM(media_collections.file_size_mb) AS "totalSizeMB",
    capture_devices.name 
FROM capture_devices 
INNER JOIN media_collections ON capture_devices.id = media_collections.device_id
WHERE   
    media_collections.upload_date > '2023-08-01'
    AND media_collections.upload_date < '2024-08-01'
    AND media_collections.status = 'ACTIVE'
    AND media_collections.is_deleted = false
    AND media_id NOT LIKE '%TMP-%'
    AND media_id NOT LIKE '%ERR-%' 
GROUP BY capture_devices.name, EXTRACT(YEAR FROM media_collections.upload_date), EXTRACT(MONTH FROM media_collections.upload_date)
HAVING SUM(media_collections.file_size_mb) < 10000
ORDER BY capture_devices.name, EXTRACT(YEAR FROM media_collections.upload_date), EXTRACT(MONTH FROM media_collections.upload_date);

-- Alternative query using the generated columns for better performance
-- This demonstrates the improvement recommended in the paper
SELECT   
    media_collections.upload_month AS "Month",
    media_collections.upload_year AS "Year",
    SUM(media_collections.file_size_mb) AS "totalSizeMB",
    capture_devices.name 
FROM capture_devices 
INNER JOIN media_collections ON capture_devices.id = media_collections.device_id
WHERE   
    media_collections.upload_date > '2023-08-01'
    AND media_collections.upload_date < '2024-08-01'
    AND media_collections.status = 'ACTIVE'
    AND media_collections.is_deleted = false
    AND media_id NOT LIKE '%TMP-%'
    AND media_id NOT LIKE '%ERR-%' 
GROUP BY capture_devices.name, media_collections.upload_year, media_collections.upload_month
HAVING SUM(media_collections.file_size_mb) < 10000
ORDER BY capture_devices.name, media_collections.upload_year, media_collections.upload_month;

-- Query demonstrating composite index effectiveness for filtering
SELECT 
    media_collections.id,
    media_collections.status,
    media_collections.upload_date,
    media_collections.file_size_mb,
    capture_devices.name
FROM media_collections
JOIN capture_devices ON media_collections.device_id = capture_devices.id
WHERE 
    media_collections.status = 'ACTIVE'
    AND media_collections.is_deleted = false
    AND media_collections.upload_date >= '2023-08-01'
ORDER BY media_collections.upload_date DESC
LIMIT 20;

-- Query demonstrating covering index effectiveness with aggregate functions
SELECT 
    media_collections.device_id,
    capture_devices.name,
    COUNT(*) as file_count,
    SUM(media_collections.file_size_mb) as total_size,
    AVG(media_collections.file_size_mb) as avg_size
FROM media_collections
JOIN capture_devices ON media_collections.device_id = capture_devices.id
WHERE media_collections.upload_date BETWEEN '2023-08-01' AND '2024-07-31'
GROUP BY media_collections.device_id, capture_devices.name
ORDER BY total_size DESC;

-- Query Execution Plan - Without optimal generated column usage
EXPLAIN ANALYZE
SELECT   
    EXTRACT(MONTH FROM media_collections.upload_date) AS "Month",
    EXTRACT(YEAR FROM media_collections.upload_date) AS "Year",
    SUM(media_collections.file_size_mb) AS "totalSizeMB",
    capture_devices.name 
FROM capture_devices 
INNER JOIN media_collections ON capture_devices.id = media_collections.device_id
WHERE   
    media_collections.upload_date > '2023-08-01'
    AND media_collections.upload_date < '2024-08-01'
    AND media_collections.status = 'ACTIVE'
    AND media_collections.is_deleted = false
GROUP BY capture_devices.name, EXTRACT(YEAR FROM media_collections.upload_date), EXTRACT(MONTH FROM media_collections.upload_date)
HAVING SUM(media_collections.file_size_mb) < 10000;

-- Query Execution Plan - With optimized generated columns
EXPLAIN ANALYZE
SELECT   
    media_collections.upload_month AS "Month",
    media_collections.upload_year AS "Year",
    SUM(media_collections.file_size_mb) AS "totalSizeMB",
    capture_devices.name 
FROM capture_devices 
INNER JOIN media_collections ON capture_devices.id = media_collections.device_id
WHERE   
    media_collections.upload_date > '2023-08-01'
    AND media_collections.upload_date < '2024-08-01'
    AND media_collections.status = 'ACTIVE'
    AND media_collections.is_deleted = false
GROUP BY capture_devices.name, media_collections.upload_year, media_collections.upload_month
HAVING SUM(media_collections.file_size_mb) < 10000;

-- Summary statistics
SELECT 'Database Statistics' as metric;
SELECT COUNT(*) as total_media_records FROM media_collections;
SELECT COUNT(*) as total_devices FROM capture_devices;
SELECT 
    SUM(file_size_mb) as total_storage_mb,
    AVG(file_size_mb) as avg_file_size_mb,
    MIN(file_size_mb) as min_file_size_mb,
    MAX(file_size_mb) as max_file_size_mb
FROM media_collections;

-- List all created indexes
SELECT tablename, indexname, indexdef 
FROM pg_indexes 
WHERE schemaname = 'public' 
AND tablename IN ('media_collections', 'capture_devices')
ORDER BY tablename, indexname;
